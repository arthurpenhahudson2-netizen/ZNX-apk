# ZNX APK — projeto Android

Este é um projeto-fonte inicial para abrir no Android Studio e compilar como APK.
Inclui uma bolha flutuante roxa, painel com sliders manuais e tentativa de abrir o Free Fire instalado.

## Como compilar
1. Extraia o ZIP em um computador com Android Studio.
2. Abra a pasta `ZNXAPK` no Android Studio.
3. Aguarde o Gradle sincronizar e instale as dependências solicitadas.
4. Use **Build > Build APK(s)** para gerar um APK de teste.
5. Instale no seu Android e autorize **Exibir sobre outros apps** nas configurações quando solicitado.

## Limites
- Este ZIP contém código-fonte, não um APK já compilado.
- O painel apenas mostra controles manuais e não envia valores para o Free Fire.
- Não injeta código, não automatiza a mira e não altera arquivos do jogo.
- O Android pode restringir sobreposição em certas telas ou versões. Teste em aparelho próprio.
- Para abrir o jogo, o app tenta os pacotes globais comuns do Free Fire e Free Fire MAX; versões regionais podem usar outros identificadores.
