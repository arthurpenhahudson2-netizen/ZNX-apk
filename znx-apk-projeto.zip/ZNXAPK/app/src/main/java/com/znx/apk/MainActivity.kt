package com.znx.apk

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val purple = 0xFF8B5CF6.toInt()
    private val bg = 0xFF130D1E.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "ZNX APK"
            textSize = 28f
            setTextColor(0xFFE9D5FF.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Painel flutuante de ajustes manuais\nNão injeta código nem altera o jogo."
            textSize = 14f
            setTextColor(0xFFD1C4E9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 22)
        }
        val permission = button("1 • Permitir sobreposição") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permissão já liberada", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val start = button("2 • Ativar painel flutuante") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Libere a permissão primeiro", Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(this, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                Toast.makeText(this, "Painel ativado", Toast.LENGTH_SHORT).show()
            }
        }
        val launch = button("Abrir Free Fire") { openFreeFire() }
        val stop = button("Fechar painel flutuante") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Painel fechado", Toast.LENGTH_SHORT).show()
        }
        layout.addView(title)
        layout.addView(desc)
        listOf(permission, start, launch, stop).forEach {
            layout.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54).apply {
                topMargin = 10
            })
        }
        setContentView(layout)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(purple)
        setOnClickListener { action() }
    }

    private fun openFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        val launchIntent = packages.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Free Fire não encontrado. Abra o jogo instalado manualmente.", Toast.LENGTH_LONG).show()
        }
    }
}
