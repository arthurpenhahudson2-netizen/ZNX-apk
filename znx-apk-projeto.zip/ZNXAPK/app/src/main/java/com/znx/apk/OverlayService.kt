package com.znx.apk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val purple = Color.rgb(139, 92, 246)
    private val dark = Color.rgb(25, 15, 39)
    private val white = Color.WHITE

    override fun onCreate() {
        super.onCreate()
        startOngoingNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun startOngoingNotification() {
        val channelId = "violet_ff_panel"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "ZNX APK", NotificationManager.IMPORTANCE_LOW))
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("ZNX APK ativo")
                .setContentText("Painel flutuante de ajustes manuais")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ZNX APK ativo")
                .setContentText("Painel flutuante de ajustes manuais")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
        startForeground(7, notification)
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 180
        }
    }

    private fun showBubble() {
        val b = Button(this).apply {
            text = "V+"
            textSize = 15f
            setTextColor(white)
            setBackgroundColor(purple)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        val p = params(130, 58)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=p.x; sy=p.y; tx=e.rawX; ty=e.rawY; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-tx).toInt(); val dy=(e.rawY-ty).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=sx+dx; p.y=sy+dy
                        wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) { if (panel == null) showPanel() else hidePanel() }
                        return true
                    }
                }
                return false
            }
        })
        wm.addView(b, p)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "VIOLET FF  •  AJUSTES"
            textSize = 16f; setTextColor(0xFFD8B4FE.toInt())
        }
        box.addView(title)
        box.addView(TextView(this).apply {
            text = "Controles manuais — não alteram o jogo."
            textSize = 11f; setTextColor(0xFFD7CBE6.toInt())
            setPadding(0, 4, 0, 8)
        })
        addSlider(box, "Geral", 85)
        addSlider(box, "Ponto vermelho", 75)
        addSlider(box, "Mira 2x", 70)
        addSlider(box, "Mira 4x", 60)
        val hide = Button(this).apply {
            text = "Ocultar painel"; setTextColor(white); setBackgroundColor(purple)
            setOnClickListener { hidePanel() }
        }
        box.addView(hide)
        panel = box
        val p = params(590, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            x = 20; y = 250
        }
        try { wm.addView(box, p) } catch (_: Exception) {
            panel = null
        }
    }

    private fun addSlider(parent: LinearLayout, label: String, initial: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 5, 0, 3) }
        val value = TextView(this).apply { text = "$label: $initial"; textSize = 12f; setTextColor(white) }
        val seek = SeekBar(this).apply {
            max = 200; progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { value.text = "$label: $v" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(value); row.addView(seek); parent.addView(row)
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
